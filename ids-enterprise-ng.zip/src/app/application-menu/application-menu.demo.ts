import {
  Component,
  ChangeDetectionStrategy
} from '@angular/core';

@Component({
  selector: 'application-menu-demo', // tslint:disable-line
  templateUrl: './application-menu.demo.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ApplicationMenuDemoComponent {
}
