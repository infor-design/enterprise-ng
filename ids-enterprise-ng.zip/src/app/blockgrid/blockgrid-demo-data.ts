export const DATA = [
  { image: 'https://randomuser.me/api/portraits/med/women/8.jpg', title: 'Sheena Taylor', subtitle: 'Infor, Developer' },
  { image: 'https://randomuser.me/api/portraits/med/women/9.jpg', title: 'Jane Taylor', subtitle: 'Infor, Developer' },
  { image: 'https://randomuser.me/api/portraits/med/women/10.jpg', title: 'Sam Smith', subtitle: 'Infor, SVP' },
  { image: 'https://randomuser.me/api/portraits/med/women/11.jpg', title: 'Mary Pane', subtitle: 'Infor, Developer' },
  { image: 'https://randomuser.me/api/portraits/med/women/12.jpg', title: 'Paula Paulson', subtitle: 'Infor, Architect' }
];
