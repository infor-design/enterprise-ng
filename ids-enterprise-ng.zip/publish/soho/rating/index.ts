export * from './soho-rating.component';
export * from './soho-rating.module';
