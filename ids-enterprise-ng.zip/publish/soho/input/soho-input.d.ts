/**
 * Soho Input.
 *
 * This file contains the Typescript mappings for the public
 * interface of the Soho jQuery input control.
 */

interface SohoInputEvent extends JQuery.Event {
}
