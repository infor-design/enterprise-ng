export * from './soho-tooltip.directive';
export * from './soho-tooltip.module';
