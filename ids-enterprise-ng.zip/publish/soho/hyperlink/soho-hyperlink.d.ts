/**
 * JQuery Hyperlink Control.
 * Soho does not provide a control api for hyperlink.
 */

interface SohoHyperlinkEvent extends JQuery.Event {
}

interface JQuery {
  hideFocus(): JQuery;
}
