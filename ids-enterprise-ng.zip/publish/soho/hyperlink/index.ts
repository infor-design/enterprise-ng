export * from './soho-hyperlink.component';
export * from './soho-hyperlink.module';
