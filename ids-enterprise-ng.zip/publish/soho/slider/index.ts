export * from './soho-slider.component';
export * from './soho-slider.module';
