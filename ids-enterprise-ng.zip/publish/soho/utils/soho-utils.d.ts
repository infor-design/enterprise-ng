interface JQueryStatic {
  createIcon(options: any): string;
  createIconPath(options: any): string;
}
