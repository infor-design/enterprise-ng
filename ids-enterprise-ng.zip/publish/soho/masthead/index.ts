export * from './soho-masthead.component';
export * from './soho-masthead.module';
