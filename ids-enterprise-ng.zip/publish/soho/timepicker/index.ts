export * from './soho-timepicker.component';
export * from './soho-timepicker.module';
