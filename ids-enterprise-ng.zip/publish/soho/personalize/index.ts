export { SohoPersonalizeDirective } from './soho-personalize.directive';
export { SohoPersonalizeModule } from './soho-personalize.module';
