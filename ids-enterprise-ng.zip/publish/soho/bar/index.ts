export * from './soho-bar.component';
export * from './soho-bar.module';
