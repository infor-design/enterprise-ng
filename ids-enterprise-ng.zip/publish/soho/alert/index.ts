export { SohoAlertDirective } from './soho-alert.directive';
export { SohoAlertModule } from './soho-alert.module';
