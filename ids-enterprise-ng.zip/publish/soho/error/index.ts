export { SohoErrorDirective } from './soho-error.directive';
export { SohoErrorModule } from './soho-error.module';
