export { SohoTreeComponent } from './soho-tree.component';
export { SohoTreeService } from './soho-tree.service';
