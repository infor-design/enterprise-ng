export * from './soho-pie.component';
export * from './soho-pie.module';
