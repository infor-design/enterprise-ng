export * from './soho-splitter.component';
export * from './soho-splitter.module';
