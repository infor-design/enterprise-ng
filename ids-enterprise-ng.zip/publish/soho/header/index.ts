export * from './soho-header.component';
export * from './soho-header.module';
