# SoHoXi Angular Component : Application Menu

## Description

This component provides access from Angular to the SoHoXi `applicationmenu` JQuery control.

The Application Menu ... 

### Usage







