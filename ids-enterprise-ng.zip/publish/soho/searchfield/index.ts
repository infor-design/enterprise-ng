export * from './soho-searchfield.component';
export * from './soho-searchfield.module';
