//tslint:disable
export { SohoWizardComponent } from './soho-wizard.component';
export { SohoWizardTickComponent } from './soho-wizard-tick.component';
export { SohoWizardHeaderComponent } from './soho-wizard-header.component';
export { SohoWizardPagesComponent } from './soho-wizard-pages.component';
export { SohoWizardPageComponent } from './soho-wizard-page.component';
export { SohoWizardButtonbarComponent } from './soho-wizard-buttonbar.component';
