export * from './soho-icon.component';
export * from './soho-icons.component';
export * from './soho-icons-extended.component';
export * from './soho-icons-empty.component';
export * from './soho-icon.module';
