export * from './soho-treemap.component';
export * from './soho-treemap.module';
