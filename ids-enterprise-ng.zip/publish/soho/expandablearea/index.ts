export * from './soho-expandablearea.component';
export * from './soho-expandablearea.module';
