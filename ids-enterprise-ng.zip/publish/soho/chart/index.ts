export * from './soho-chart.component';
export * from './soho-chart.module';
