export * from './soho-column.component';
export * from './soho-column.module';
