export * from './soho-bullet.component';
export * from './soho-bullet.module';
