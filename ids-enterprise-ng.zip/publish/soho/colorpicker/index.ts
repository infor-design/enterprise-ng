export * from './soho-colorpicker.component';
export * from './soho-colorpicker.module';
