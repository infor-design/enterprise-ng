/**
 * Soho Checkbox.
 *
 * This file contains the Typescript mappings for the public
 * interface of the Soho jQuery checkbox control.
 */

interface SohoCheckBoxEvent extends JQuery.Event {
}
