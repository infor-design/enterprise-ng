export * from './soho-textarea.component';
export * from './soho-textarea.module';
