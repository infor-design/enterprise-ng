export * from './soho-tabs.component';
export * from './soho-tabs.module';
