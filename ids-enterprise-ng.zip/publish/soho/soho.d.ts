// tslint:disable
/// <reference path="./soho-components.d.ts" />
// tslint:enable

/**
 * JQuery Integration
 */
interface JQueryStatic {
}

interface JQuery {
}
