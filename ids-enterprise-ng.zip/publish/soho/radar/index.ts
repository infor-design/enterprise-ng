export * from './soho-radar.component';
export * from './soho-radar.module';
