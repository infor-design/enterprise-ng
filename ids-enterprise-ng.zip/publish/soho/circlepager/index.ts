export * from './soho-circlepager.component';
export * from './soho-circlepager.module';
