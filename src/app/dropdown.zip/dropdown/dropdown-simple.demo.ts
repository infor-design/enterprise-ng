import {
  Component,
  AfterViewInit,
  ViewChild,
  ChangeDetectorRef,
  ChangeDetectionStrategy
} from '@angular/core';

import { SohoDropDownComponent } from 'ids-enterprise-ng';

import { MOCK_STATES } from './dropdown-mock.data';

@Component({
  selector: 'soho-dropdown-simple-demo',
  templateUrl: './dropdown-simple.demo.html',
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DropdownSimpleDemoComponent implements AfterViewInit {
   @ViewChild(SohoDropDownComponent) dropDownComponent: SohoDropDownComponent;

  /** Defautl selected item.  */
  model = { selectedOption: 'ND' };

  showModel = false;

  /** Used the html to comntrol the options. */
  options = [];

  constructor(private changeDetectorRef: ChangeDetectorRef) {}

  ngAfterViewInit() {
    this.initialise();
  }

  toggleModel() {
    this.showModel = !this.showModel;
  }

  initialise() {
    // Retrieve data from AJAX service and call resonse.
    // setTimeout simulates the behaviour of a rest service
    setTimeout(() => {
      this.options = MOCK_STATES;
      setTimeout((f) => {
        this.changeDetectorRef.markForCheck();
        this.dropDownComponent.updated();
      }, 1000);
    });
  }
}
